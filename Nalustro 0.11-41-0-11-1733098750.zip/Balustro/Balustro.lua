-- LOAD OTHER FILES --
-- Contains Config and Credits pages
SMODS.load_file("UI.lua")()

-- Contains all texture replacements
SMODS.load_file("textures.lua")()

-- Contains all text changes
SMODS.load_file("text.lua")()

-- Takes silent ownership of a bunch of objects to make
-- make them show up in the additions tab.
SMODS.load_file("additions.lua")()