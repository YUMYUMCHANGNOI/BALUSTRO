local joker_list = {
    --- PAGE 1 ---
    "j_joker",
    "j_greedy_joker",
    "j_lusty_joker",
    "j_wrathful_joker",
    "j_gluttenous_joker",
    "j_jolly",
    "j_zany",
    "j_mad",
    "j_crazy",
    "j_droll",
    "j_sly",
    "j_wily",
    "j_clever",
    "j_devious",
    "j_crafty",
    --- PAGE 2 ---
    "j_half",
    "j_mime",
    "j_marble",
    "j_misprint",
    "j_chaos",
    --- PAGE 3 ---
    "j_steel_joker",
    "j_scary_face",
    "j_abstract",
    "j_scholar",
    "j_business",
    "j_space",
    --- PAGE 4 ---
    "j_egg",
    "j_runner",
    "j_splash",
    --- PAGE 5 ---
    "j_madness",
    "j_vampire",
    --- PAGE 6 ---
    "j_midas_mask",
    "j_fortune_teller",
    --- PAGE 7 ---
    "j_lucky_cat",
    "j_bull",
    "j_trousers",
    "j_walkie_talkie",
    "j_smiley",
    --- PAGE 8 ---
    "j_mr_bones",
    "j_acrobat",
    "j_swashbuckler",
    "j_rough_gem",
    "j_bloodstone",
    "j_arrowhead",
    "j_onyx_agate",
    "j_glass",
    --- PAGE 9 ---
    "j_ring_master",
    "j_wee",
    "j_duo",
    "j_trio",
    "j_family",
    "j_order",
    "j_tribe",
    --- PAGE 10 --
    "j_stuntman",
    "j_invisible",
    "j_burnt",
}
local consumable_list = {
    --- TAROT ---
    "c_judgement",
    --- PLANET ---
    "c_jupiter",
    "c_saturn",
    "c_uranus",
    "c_planet_x",
    --- SPECTRAL ---
    "c_familiar",
    "c_grim",
    "c_ouija",
    "c_ectoplasm",
    "c_immolate",
    "c_ankh",
    "c_trance",
}
local deck_list = {
    'b_red',
    'b_blue',
    'b_yellow',
    'b_green',
    'b_black',
    'b_abandoned',
    'b_painted',
}
for k, v in pairs(joker_list) do
    SMODS.Joker:take_ownership(v,{},true)
end
for k, v in pairs(deck_list) do
    SMODS.Back:take_ownership(v,{},true)
end