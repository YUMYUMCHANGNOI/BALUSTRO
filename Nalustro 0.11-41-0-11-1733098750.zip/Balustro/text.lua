local config = SMODS.current_mod.config

for i, v in pairs(SMODS.Mods) do
  sendDebugMessage(tostring(i), 'AvailableMods')
end


function SMODS.current_mod.process_loc_text()
  if config.Names then
    -- All 150 Joker Names
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_joker, "name", "Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_jolly, "name", "Horny Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_zany, "name", "Slutty Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mad, "name", "Pervy Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_crazy, "name", "Naughty Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_droll, "name", "Degenerate Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_sly, "name", "Flirty Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_wily, "name", "Seductive Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_clever, "name", "Sultry Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_devious, "name", "Tantalizing Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_crafty, "name", "Erotic Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_half, "name", "Half Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_fortune_teller, "name", "Fortune Teller")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_juggler, "name", "Juggler")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_drunkard, "name", "Drunkard")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_stone, "name", "Stone Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_golden, "name", "Golden Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_stencil, "name", "Harlot Stencil")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_four_fingers, "name", "Four Fingers")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mime, "name", "Chuchu the Mime")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_credit_card, "name", "Credit Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_greedy_joker, "name", "Greedy Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_lusty_joker, "name", "Lusty Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_wrathful_joker, "name", "Bratty Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_gluttenous_joker, "name", "Gluttonous Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ceremonial, "name", "Ceremonial Dagger")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_banner, "name", "Banner")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mystic_summit, "name", "Mystic Summit")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_marble, "name", "Medusa")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_loyalty_card, "name", "Loyalty Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_8_ball, "name", "8 Ball")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_dusk, "name", "Dusk")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_chaos, "name", "Chaos the Clown")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_misprint, "name", "Ms. Print")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_raised_fist, "name", "Raised Fist")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_fibonacci, "name", "Fibonacci")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_steel_joker, "name", "ROBO-JOKER")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_scary_face, "name", "Ahegao Face")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_abstract, "name", "Abstract Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_delayed_grat, "name", "Delayed Gratification")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_pareidolia, "name", "Pareidolia")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hack, "name", "Hack")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_gros_michel, "name", "Gros Michel")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_even_steven, "name", "Even Evelyn")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_odd_todd, "name", "Odd Dottie")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_scholar, "name", "Scholar")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_business, "name", "Pole Dancer")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_supernova, "name", "Supernova")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_superposition, "name", "Superposition")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ride_the_bus, "name", "Ride the Bus")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_space, "name", "Alien Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_egg, "name", "Eggs")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_burglar, "name", "Burglar")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_blackboard, "name", "Blackboard")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_runner, "name", "Runner")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ice_cream, "name", "Ice Cream")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_dna, "name", "DNA")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_splash, "name", "Squirt")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_blue_joker, "name", "Blue Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_sixth_sense, "name", "Sixth Sense")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_constellation, "name", "Constellation")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hiker, "name", "Hiker")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_faceless, "name", "Faceless Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_todo_list, "name", "To Do List")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ticket, "name", "Golden Ticket")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mr_bones, "name", "La Muerte")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_acrobat, "name", "Acrobat")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_sock_and_buskin, "name", "Sock and Buskin")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_green_joker, "name", "Green Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_swashbuckler, "name", "Swashbuckler")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_troubadour, "name", "Troubadour")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_certificate, "name", "Certificate")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_smeared, "name", "Smeared Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_throwback, "name", "Throwback")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hanging_chad, "name", "Hanging Chad")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_rough_gem, "name", "Dildo")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_bloodstone, "name", "Vibrators")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_arrowhead, "name", "Buttplug")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_onyx_agate, "name", "Jar of Cum")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_glass, "name", "Glass Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ring_master, "name", " Martingale & Charlie ")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_flower_pot, "name", "Flower Pot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_blueprint, "name", "Blueprint")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_wee, "name", "Fairy Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_merry_andy, "name", "Merry Andy")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_oops, "name", "Oops! All 6s")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_idol, "name", "The Idol")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_seeing_double, "name", "Seeing Double")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_matador, "name", "Matador")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hit_the_road, "name", "Hit the Road")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_duo, "name", "The Duo")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_trio, "name", "The Trio")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_family, "name", "The Family")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_order, "name", "The Order")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_tribe, "name", "The Tribe")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_cavendish, "name", "Cavendish")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_card_sharp, "name", "Card Sharp")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_red_card, "name", "Red Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_madness, "name", "Seedbed")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_square, "name", "Square Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_seance, "name", "Séance")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_riff_raff, "name", "Riff-Raff")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_vampire, "name", "Vampire")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_shortcut, "name", "Shortcut")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hologram, "name", "Hologram")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_vagabond, "name", "Vagabond")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_baron, "name", "Baron")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_cloud_9, "name", "Cloud 9")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_rocket, "name", "Rocket")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_obelisk, "name", "Obelisk")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_midas_mask, "name", "Midas Mask")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_luchador, "name", "Luchador")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_photograph, "name", "Photograph")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_gift, "name", "Gift Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_turtle_bean, "name", "Turtle Bean")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_erosion, "name", "Erosion")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_reserved_parking, "name", "Reserved Parking")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mail, "name", "Mail-In Rebate")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_to_the_moon, "name", "To the Moon")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hallucination, "name", "Hallucination")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_lucky_cat, "name", "Lucky Pussy")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_baseball, "name", "Baseball Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_bull, "name", "Cash Cow")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_diet_cola, "name", "Diet Cola")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_trading, "name", "Trading Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_flash, "name", "Flash Card")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_popcorn, "name", "Popcorn")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ramen, "name", "Ramen")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_trousers, "name", "Spare Trousers")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ancient, "name", "Ancient Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_walkie_talkie, "name", "Walkie Talkie")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_selzer, "name", "Seltzer")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_castle, "name", "Castle")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_smiley, "name", "Happy Facial")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_campfire, "name", "Campfire")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_stuntman, "name", "Stuntwoman")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_invisible, "name", "Invisible Harlot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_brainstorm, "name", "Brainstorm")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_satellite, "name", "Satellite")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_shoot_the_moon, "name", "Shoot the Moon")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_drivers_license, "name", "Driver's License")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_cartomancer, "name", "Cartomancer")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_astronomer, "name", "Astronomer")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_burnt, "name", "Succubus")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_bootstraps, "name", "Bootstraps")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_caino, "name", "Canio")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_triboulet, "name", "Triboulet")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_yorick, "name", "Yorick")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_chicot, "name", "Chicot")
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_perkeo, "name", "Perkeo")

    -- Jokers that mention jokers in their descriptions
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_stencil, "text",
      { "{X:red,C:white} X1 {} Mult for each", "empty {C:attention}Harlot{} slot", "{s:0.8}Harlot Stencil included",
        "{C:inactive}(Currently {X:red,C:white} X#1# {C:inactive})" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ceremonial, "text",
      { "When {C:attention}Blind{} is selected,", "destroy Harlot to the right",
        "and permanently add {C:attention}double", "its sell value to this {C:red}Mult",
        "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_abstract, "text",
      { "{C:mult}+#1#{} Mult for", "each {C:attention}Harlot{} card",
        "{C:inactive}(Currently {C:red}+#2#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ride_the_bus, "text",
      { "This Harlot gains {C:mult}+#1#{} Mult", "per {C:attention}consecutive{} hand", "played without a",
        "scoring {C:attention}face{} card", "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_constellation, "text",
      { "This Harlot gains", "{X:mult,C:white} X#1# {} Mult every time", "a {C:planet}Planet{} card is used",
        "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_swashbuckler, "text",
      { "Adds the sell value", "of all other owned", "{C:attention}Harlots{} to Mult",
        "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_glass, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "for every {C:attention}Glass Card", "that is destroyed",
        "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_ring_master, "text",
      { "{C:attention}Harlot{}, {C:tarot}Tarot{}, {C:planet}Planet{},", "and {C:spectral}Spectral{} cards may",
        "appear multiple times" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_blueprint, "text",
      { "Copies ability of", "{C:attention}Harlot{} to the right" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_wee, "text",
      { "This Harlot gains", "{C:chips}+#2#{} Chips when each", "played {C:attention}2{} is scored",
        "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hit_the_road, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "for every {C:attention}Jack{}", "discarded this round",
        "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_red_card, "text",
      { "This Harlot gains", "{C:red}+#1#{} Mult when any", "{C:attention}Booster Pack{} is skipped",
        "{C:inactive}(Currently {C:red}+#2#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_madness, "text",
      { "When {C:attention}Small Blind{} or {C:attention}Big Blind{}", "is selected, gain {X:mult,C:white} X#1# {} Mult",
        "and {C:attention}destroy{} a random Harlot", "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_square, "text",
      { "This Harlot gains {C:chips}+#2#{} Chips", "if played hand has", "exactly {C:attention}4{} cards",
        "{C:inactive}(Currently {C:chips}#1#{C:inactive} Chips)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_vampire, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "per scoring {C:attention}Enhanced card{} played,",
        "removes card {C:attention}Enhancement", "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_hologram, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "every time a {C:attention}playing card{}",
        "is added to your deck", "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_obelisk, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "per {C:attention}consecutive{} hand played",
        "without playing your", "most played {C:attention}poker hand",
        "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_gift, "text",
      { "Add {C:money}$#1#{} of {C:attention}sell value", "to every {C:attention}Harlot{} and",
        "{C:attention}Consumable{} card at", "end of round" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_lucky_cat, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "every time a {C:attention}Lucky{} card",
        "{C:green}successfully{} triggers", "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_baseball, "text",
      { "{C:green}Kinky{} Harlots", "each give {X:mult,C:white} X#1# {} Mult" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_flash, "text",
      { "This Harlot gains {C:mult}+#1#{} Mult", "per {C:attention}reroll{} in the shop",
        "{C:inactive}(Currently {C:mult}+#2#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_trousers, "text",
      { "This Harlot gains {C:mult}+#1#{} Mult", "if played hand contains", "a {C:attention}#2#",
        "{C:inactive}(Currently {C:red}+#3#{C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_castle, "text",
      { "This Harlot gains {C:chips}+#1#{} Chips", "per discarded {V:1}#2#{} card,", "suit changes every round",
        "{C:inactive}(Currently {C:chips}+#3#{C:inactive} Chips)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_campfire, "text",
      { "This Harlot gains {X:mult,C:white}X#1#{} Mult", "for each card {C:attention}sold{}, resets",
        "when {C:attention}Boss Blind{} is defeated", "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_invisible, "text",
      { "After {C:attention}#1#{} rounds,", "sell this card to", "{C:attention}Duplicate{} a random Harlot",
        "{C:inactive}(Currently {C:attention}#2#{C:inactive}/#1#)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_brainstorm, "text",
      { "Copies the ability", "of the leftmost {C:attention}Harlot" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_caino, "text",
      { "This Harlot gains {X:mult,C:white} X#1# {} Mult", "when a {C:attention}face{} card", "is destroyed",
        "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)" })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_yorick, "text",
      { "This Harlot gains", "{X:mult,C:white} X#1# {} Mult every {C:attention}#2#{C:inactive} [#3#]{}",
        "cards discarded", "{C:inactive}(Currently {X:mult,C:white} X#4# {C:inactive} Mult)" })

    -- Various things that mention Jokers.
    SMODS.process_loc_text(G.localization.descriptions.Voucher.v_antimatter, "text",
      { "{C:dark_edition}+1{} Harlot Slot" })
    SMODS.process_loc_text(G.localization.descriptions.Tarot.c_temperance, "text",
      { "Gives the total sell", "value of all current", "Harlots {C:inactive}(Max of {C:money}$#1#{C:inactive})",
        "{C:inactive}(Currently {C:money}$#2#{C:inactive})" })
    SMODS.process_loc_text(G.localization.descriptions.Tarot.c_judgement, "text",
      { "Creates a random", "{C:attention}Harlot{} card", "{C:inactive}(Must have room)" })
    SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ankh, "text",
      { "Create a copy of a", "random {C:attention}Harlot{}, destroy", "all other Jokers" })

    SMODS.process_loc_text(G.localization.descriptions.Blind.bl_final_leaf, "text",
      { "All cards debuffed", "until 1 Harlot sold" })
    SMODS.process_loc_text(G.localization.descriptions.Blind.bl_final_acorn, "text",
      { "Flips and shuffles", "all Harlot cards" })
    SMODS.process_loc_text(G.localization.descriptions.Blind.bl_final_heart, "text",
      { "One random Harlot", "disabled every hand" })
    SMODS.process_loc_text(G.localization.descriptions.Back.b_black, "text",
      { "{C:attention}+#1#{} Harlot slot", "", "{C:blue}-#2#{} hand", "every round" })
    SMODS.process_loc_text(G.localization.descriptions.Back.b_painted, "text",
      { "{C:attention}+#1#{} hand size,", "{C:red}#2#{} Harlot slot" })

    -- SMODS.process_loc_text(G.localization.descriptions.Other.white_sticker, "name", "Pastie/Tattoo")


    if config.Extras < 3 then
      SMODS.process_loc_text(G.localization.descriptions.Stake.stake_black, "text",
        { "Shop can have {C:attention}Eternal{} Harlots", "{C:inactive,s:0.8}(Can't be sold or destroyed)",
          "{s:0.8}Applies all previous Stakes" })
      SMODS.process_loc_text(G.localization.descriptions.Stake.stake_orange, "text",
        { "Shop can have {C:attention}Perishable{} Harlots", "{C:inactive,s:0.8}(Debuffed after 5 Rounds)",
          "{s:0.8}Applies all previous Stakes" })
      SMODS.process_loc_text(G.localization.descriptions.Stake.stake_gold, "text",
        { "Shop can have {C:attention}Rental{} Harlots",
          "{C:inactive,s:0.8}(Costs {C:money,s:0.8}$3{C:inactive,s:0.8} per round)", "{s:0.8}Applies all previous Stakes" })
    end

    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_normal, "name", "Jezebel Pack")
    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_jumbo, "name", "Jumbo Jezebel Pack")
    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_mega, "name", "Mega Jezebel Pack")


    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_normal, "text",
      { "Choose {C:attention}#1#{} of up to", "{C:attention}#2#{C:joker} Harlot{} cards" })
    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_jumbo, "text",
      { "Choose {C:attention}#1#{} of up to", "{C:attention}#2#{C:joker} Harlot{} cards" })
    SMODS.process_loc_text(G.localization.descriptions.Other.p_buffoon_mega, "text",
      { "Choose {C:attention}#1#{} of up to", "{C:attention}#2#{C:joker} Harlot{} cards" })
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_buffoon_pack", "Jezebel Pack")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_buffoon, "name", "Jezebel Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_buffoon, "text",
      { "Shop has a free", "{C:attention}Mega Jezebel Pack" })

    SMODS.process_loc_text(G.localization.descriptions.Other.pinned_left, "text",
      { "This Harlot stays", "pinned to the", "leftmost position" })

    --		SMODS.process_loc_text(G.localization.descriptions.., "text", {})
    --		SMODS.process_loc_text(G.localization.descriptions.., "text", {})
    --		SMODS.process_loc_text(G.localization.descriptions.., "text", {})
    --		SMODS.process_loc_text(G.localization.descriptions.., "text", {})
    SMODS.process_loc_text(G.localization.misc.dictionary, "b_stat_jokers", "Harlots")
    SMODS.process_loc_text(G.localization.misc.dictionary, "b_jokers", "Harlots")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_joker", "Harlot")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_jokers_cap", "HARLOTS")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_joker_stickers", "Harlot Stickers") -- Consider Pasties or Tattoos
    SMODS.process_loc_text(G.localization.misc.dictionary, "ph_deck_preview_effective",
      "Effective total due to Harlots, Blinds, and card enhancements")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_no_other_jokers", "No Other Harlots!")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_plus_joker", "+1 Harlot")
    SMODS.process_loc_text(G.localization.misc.v_text, "ch_m_joker_slots", { "{C:attention}#1#{} Harlot Slots" })
    SMODS.process_loc_text(G.localization.misc.v_text, "ch_c_no_shop_jokers",
      { "Harlots no longer appear in the {C:attention}shop" })
    SMODS.process_loc_text(G.localization.misc.v_text, "ch_c_all_eternal", { "All Harlots are {C:eternal}Eternal{}" })
    SMODS.process_loc_text(G.localization.misc.v_text, "ch_c_set_eternal_ante",
      { "When ante {C:attention}#1#{} boss is defeated, all Harlots become {C:attention}eternal" })
    SMODS.process_loc_text(G.localization.misc.challenge_names, "c_jokerless_1", "Maidenless")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_negative, "text",
      { "{C:dark_edition}+#1#{} Harlot slot" })


    SMODS.process_loc_text(G.localization.misc.dictionary, "ph_mr_bones", "Saved by La Muerta")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_voucher, "name", 'Smut Tag')
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_voucher, "text",
      { 'Adds one Smut Flick', 'to the next Brothel' })




    if config.Extras < 2 then
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_wraith, "text",
        { "Creates a random", "{C:red}Rare{C:attention} Harlot{},", "sets money to {C:money}$0" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_soul, "text",
        { "Creates a", "{C:legendary,E:1}Legendary{} Harlot", "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_riff_raff, "text",
        { "When {C:attention}Blind{} is selected,", "create {C:attention}#1# {C:blue}Common{C:attention} Harlots",
          "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_baseball, "text",
        { "{C:green}Uncommon{} Harlots", "each give {X:mult,C:white} X#1# {} Mult" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_uncommon, "text",
        { "Shop has a free", "{C:green}Uncommon Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_rare, "text",
        { "Shop has a free", "{C:red}Rare Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_top_up, "text",
        { "Create up to {C:attention}#1#", "{C:blue}Common{} Harlots", "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_wraith, "text",
        { "Creates a random", "{C:red}Rare{C:attention} Harlot{},", "sets money to {C:money}$0" })
    end
    if config.Extras < 3 then
      SMODS.process_loc_text(G.localization.descriptions.Tarot.c_wheel_of_fortune, "text",
        { "{C:green}#1# in #2#{} chance to add", "{C:dark_edition}Foil{}, {C:dark_edition}Holographic{}, or",
          "{C:dark_edition}Polychrome{} edition", "to a random {C:attention}Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ectoplasm, "text",
        { "Add {C:dark_edition}Negative{} to", "a random {C:attention}Harlot,", "{C:red}-#1#{} hand size" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_hex, "text",
        { "Add {C:dark_edition}Polychrome{} to a", "random {C:attention}Harlot{}, destroy", "all other Harlots" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Negative" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Foil" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Holographic" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Polychrome" })
      SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_desc", { "Negative", "+#1# Harlot Slot" })
    end
  end


  if config.Descriptions then
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_mime, "text", {
      "She mimics the cards, as",
      "well as some lewder motions,",
      "retriggering all card",
      "{C:attention}held in hand{} abilities"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_greedy_joker, "text", {
      "This greedy slut needs",
      "to be filled even more.",
      "She gives played cards",
      "with the {C:diamonds}#2#{} suit",
      "{C:mult}+#1#{} Mult when scored",
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_lusty_joker, "text", {
      "This lusty whore is",
      "always in the mood.",
      "She gives played cards",
      "with the {C:hearts}#2#{} suit",
      "{C:mult}+#1#{} Mult when scored",
      "{C:inactive}Bzzzt... Bzzzzzzt..."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_wrathful_joker, "text", {
      "This bratty bitch gives",
      "your played cards with",
      "the {C:spades}#2#{} suit give",
      "{C:mult}+#1#{} Mult when scored",
      "and a nice spread view."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_gluttenous_joker, "text", {
      "This gluttonous gal can't",
      "ever get enough cum.",
      "She gives played cards ",
      "with the {C:clubs}#2#{} suit",
      "{C:mult}+#1#{} Mult when scored"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_chaos, "text", {
      "She distracts the",
      "shopkeeper, giving you",
      "{C:attention}#1#{} free {C:green}Reroll{} per shop"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_scary_face, "text", {
      "Her drool drips onto",
      "played {C:attention}face{} cards,",
      "giving them {C:chips}+#1#{} Chips",
      "when they're scored."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_splash, "text", {
      "This harlot squirts",
      "all over the cards.",
      "Every {C:attention}played card",
      "counts in scoring",
      "and gets a bit wet."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_acrobat, "text", {
      "She shows her body",
      "off, leading to a",
      "{X:red,C:white} X#1# {} Mult on the {C:attention}final",
      "{C:attention}hand{} of the round"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_rough_gem, "text", {
      "Thrusting in and",
      "out with this gives",
      "played cards with",
      "{C:diamonds}Diamond{} suit earn",
      "{C:money}$#1#{} when scored",
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_bloodstone, "text", {
      "These pink eggs give a",
      "{C:green}#1# in #2#{} chance for",
      "played cards with",
      "{C:hearts}Heart{} suit to give",
      "{X:mult,C:white} X#3# {} Mult when scored",
      "{C:inactive}Bzzt... Bzzt... BZZZZZT..."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_arrowhead, "text", {
      "Keeping this inside makes",
      "your played cards with",
      "{C:spades}Spade{} suit give",
      "{C:chips}+#1#{} Chips when scored"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_onyx_agate, "text", {
      "A bit of cum drips",
      "onto the cards. Now",
      "played cards with",
      "the {C:clubs}Club{} suit give",
      "{C:mult}+#1#{} Mult when scored."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_vampire, "text", {
      "This Harlot sucks out {X:mult,C:white} X#1# {} Mult",
      "per scoring {C:attention}Enhanced card{} played.",
      "Removes card {C:attention}Enhancement",
      "{C:inactive}(Currently {X:mult,C:white} X#2# {C:inactive} Mult)"
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_smiley, "text", {
      "Her love for all the cum",
      "on her magically gives all",
      "played {C:attention}face{} cards give",
      "{C:mult}+#1#{} Mult when scored."
    })
    SMODS.process_loc_text(G.localization.descriptions.Joker.j_bull, "text", {
      "Selling off her milk",
      "gives {C:chips}+#1#{} Chips for",
      "each {C:money}$1{} you have",
      "{C:inactive}(Currently {C:chips}+#2#{C:inactive} Chips)"
    })
    --      SMODS.process_loc_text(G.localization.descriptions.Joker.j_ring_master, "text", {
    --          "{C:attention}Joker{}, {C:tarot}Tarot{}, {C:planet}Planet{},",
    --          "and {C:spectral}Spectral{} cards may",
    --          "appear multiple times"
    --        })

    SMODS.process_loc_text(G.localization.misc.quips, "wq_1", { "Are you", "ready for", "sloppy seconds?" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_2", { "That got me", "feeling {C:important}flush{}~" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_3", { "Talk about a", "happy ending~!" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_4", { "You really put", "those hands", "to work~!" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_5",
      { "How about you", "lay {C:important}ME{} on the", "table next~?" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_6",
      { "Scoring {C:chips}chips{}", "and shaking {C:mult}hips{}!" })
    SMODS.process_loc_text(G.localization.misc.quips, "wq_7", { "Too bad these", "tits are all", "virtual..." })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_1", { "{C:inactive}...was that it?" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_2", { "Not the first", "time you've", "come up short." })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_3",
      { "Hey, I know I'm", "pretty, but let's", "focus up a lil'!" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_4", { "Well... That", "was premature." })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_5", { "What's wrong,", "too much", "to handle?" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_6", { "You're out of", "your league!" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_7", { "I guess you", "did your best?" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_8", { "Get your", "{C:gold}money{} up, not", "your funny up." })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_9", { "I'm literally", "a bimbo, what's", "your excuse?" })
    SMODS.process_loc_text(G.localization.misc.quips, "lq_10", { "What a {C:important}Tease!" })


    --  SMODS.process_loc_text(G.localization.descriptions.Other.Dorian, "name", "Artist")
    --  SMODS.process_loc_text(G.localization.descriptions.Other.Dorian, "text", {"Dorian Bates"})
    --  SMODS.process_loc_text(G.localization.descriptions.Other.PMQ, "name", "Artist")
    --  SMODS.process_loc_text(G.localization.descriptions.Other.PMQ, "text", {"PaperMoonQueen"})
    --  SMODS.process_loc_text(G.localization.descriptions.Other.TiltedH, "name", "Artist")
    --  SMODS.process_loc_text(G.localization.descriptions.Other.TiltedH, "text", {"Mr. Oddman"})


    G.localization.descriptions.Other['Dorian'] = { name = 'Artist', text = { 'Dorian Bates' } }

    G.localization.descriptions.Other['PMQ'] = { name = 'Artist', text = { 'PaperMoonQueen' } }

    G.localization.descriptions.Other['TiltedH'] = { name = 'Artist', text = { 'Mr. Oddman' } }
  end



  if config.Extras > 1 then
    SMODS.process_loc_text(G.localization.misc.labels, "common", "Vanilla")
    SMODS.process_loc_text(G.localization.misc.labels, "uncommon", "Kinky")
    SMODS.process_loc_text(G.localization.misc.labels, "rare", "Depraved")
    SMODS.process_loc_text(G.localization.misc.labels, "legendary", "Lascivious")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_common", "Vanilla")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_uncommon", "Kinky")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_rare", "Depraved")
    SMODS.process_loc_text(G.localization.misc.dictionary, "k_legendary", "Lascivious")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_uncommon, "name", "Kinky Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_rare, "name", "Depraved Tag")

    if config.Names then
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_wraith, "text",
        { "Creates a random", "{C:red}Depraved{C:attention} Harlot{},", "sets money to {C:money}$0" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_soul, "text",
        { "Creates a", "{C:legendary,E:1}Lascivious{} Harlot", "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_riff_raff, "text",
        { "When {C:attention}Blind{} is selected,", "create {C:attention}#1# {C:blue}Vanilla{C:attention} Harlots",
          "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_baseball, "text",
        { "{C:green}Kinky{} Harlots", "each give {X:mult,C:white} X#1# {} Mult" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_uncommon, "text",
        { "Shop has a free", "{C:green}Kinky Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_rare, "text",
        { "Shop has a free", "{C:red}Depraved Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_top_up, "text",
        { "Create up to {C:attention}#1#", "{C:blue}Vanilla{} Harlots", "{C:inactive}(Must have room)" })
    else
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_wraith, "text",
        { "Creates a random", "{C:red}Raunchy{C:attention} Joker{},", "sets money to {C:money}$0" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_soul, "text",
        { "Creates a", "{C:legendary,E:1}Lascivious{} Joker", "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_riff_raff, "text",
        { "When {C:attention}Blind{} is selected,", "create {C:attention}#1# {C:blue}Horny{C:attention} Jokers",
          "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_baseball, "text",
        { "{C:green}Kinky{} Jokers", "each give {X:mult,C:white} X#1# {} Mult" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_uncommon, "text",
        { "Shop has a free", "{C:green}Kinky Joker" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_rare, "text", { "Shop has a free",
        "{C:red}Raunchy Joker" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_top_up, "text",
        { "Create up to {C:attention}#1#", "{C:blue}Vanilla{} Jokers", "{C:inactive}(Must have room)" })
    end
  end

  if config.Stickers == 2 then
    SMODS.process_loc_text(G.localization.descriptions.Other.white_sticker, "name", "White Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.white_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}White", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.red_sticker, "name", "Red Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.red_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Red", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.green_sticker, "name", "Green Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.green_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Green", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.blue_sticker, "name", "Blue Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.blue_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Blue", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.black_sticker, "name", "Black Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.black_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Black", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.purple_sticker, "name", "Purple Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.purple_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Purple", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.orange_sticker, "name", "Orange Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.orange_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Orange", "{C:attention}Stake{} difficulty" })
    SMODS.process_loc_text(G.localization.descriptions.Other.gold_sticker, "name", "Gold Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.gold_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Gold", "{C:attention}Stake{} difficulty" })
  elseif config.Stickers > 2 then
    SMODS.process_loc_text(G.localization.descriptions.Other.white_sticker, "name", "Lipstick Mark")
    SMODS.process_loc_text(G.localization.descriptions.Other.white_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}White", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.red_sticker, "name", "Vibrators")
    SMODS.process_loc_text(G.localization.descriptions.Other.red_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Red", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.green_sticker, "name", "Opened Condoms")
    SMODS.process_loc_text(G.localization.descriptions.Other.green_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Green", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.black_sticker, "name", "Tally Marks")
    SMODS.process_loc_text(G.localization.descriptions.Other.black_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Black", "{C:attention}Stake{} difficulty",
        "{C:inactive}That makes five.{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.blue_sticker, "name", "Eastern Tally Marks")
    SMODS.process_loc_text(G.localization.descriptions.Other.blue_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Blue", "{C:attention}Stake{} difficulty",
        "{C:inactive}Six... Seven... Eight...{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.purple_sticker, "name", "Naughty Writing")
    SMODS.process_loc_text(G.localization.descriptions.Other.purple_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Purple", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.orange_sticker, "name", "Condom")
    SMODS.process_loc_text(G.localization.descriptions.Other.orange_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Orange", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
    SMODS.process_loc_text(G.localization.descriptions.Other.gold_sticker, "name", "Glistening Coating")
    SMODS.process_loc_text(G.localization.descriptions.Other.gold_sticker, "text",
      { "Used this Harlot", "to win on {C:attention}Gold", "{C:attention}Stake{} difficulty",
        "{C:inactive}Insert Witty Thing Here{}" })
  end





  if config.Extras > 2 and not config.WIP then
    SMODS.process_loc_text(G.localization.misc.labels, "foil", "Oiled")
    SMODS.process_loc_text(G.localization.misc.labels, "holographic", "Cum Covered")
    SMODS.process_loc_text(G.localization.misc.labels, "polychrome", "Cursemarked")
    SMODS.process_loc_text(G.localization.misc.labels, "negative", "Lubricated")

    SMODS.process_loc_text(G.localization.descriptions.Edition.e_foil, "name", "Oiled")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_holo, "name", "Cum Covered")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_polychrome, "name", "Cursemarked")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_negative, "name", "Lubricated")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_negative_consumable, "name", "Lubricated")

    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "name", "Oiled Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "name", "Cum Covered Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "name", "Cursemarked Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "name", "Lubricated Tag")


    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_foil_desc", { "Oiled", "+#1# Chips" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_holo_desc", { "Cum Covered", "+#1# Mult" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_polychrome_desc", { "Cursemarked", "X#1# Mult" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_consumable_desc",
      { "Lubricated", "+#1# consumable Slot" })
    SMODS.process_loc_text(G.localization.descriptions.Voucher.v_hone, "text",
      { "{C:dark_edition}Oiled{}, {C:dark_edition}Cum Covered{}, and", "{C:dark_edition}Cursemarked{} cards",
        "appear {C:attention}#1#X{} more often" })
    SMODS.process_loc_text(G.localization.descriptions.Voucher.v_glow_up, "text",
      { "{C:dark_edition}Oiled{}, {C:dark_edition}Cum Covered{}, and", "{C:dark_edition}Cursemarked{} cards",
        "appear {C:attention}#1#X{} more often" })
    SMODS.process_loc_text(G.localization.descriptions.Spectral.c_aura, "text",
      { "Add {C:dark_edition}Oiled{}, {C:dark_edition}Cum Covered{},", "or {C:dark_edition}Cursemarked{} effect to",
        "{C:attention}1{} selected card in hand" })

    if config.Names then
      SMODS.process_loc_text(G.localization.descriptions.Tarot.c_wheel_of_fortune, "text",
        { "{C:green}#1# in #2#{} chance to add", "{C:dark_edition}Oiled{}, {C:dark_edition}Cum Covered{}, or",
          "{C:dark_edition}Cursemarked{} edition", "to a random {C:attention}Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ectoplasm, "text",
        { "Add {C:dark_edition}Lubricated{} to", "a random {C:attention}Harlot,", "{C:red}-#1#{} hand size" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_hex, "text",
        { "Add {C:dark_edition}Cursemarked{} to a", "random {C:attention}Harlot{}, destroy", "all other Harlots" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Lubricated" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Oiled" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Cum Covered" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Cursemarked" })
      SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_desc", { "Lubricated", "+#1# Harlot Slot" })
    else
      SMODS.process_loc_text(G.localization.descriptions.Tarot.c_wheel_of_fortune, "text",
        { "{C:green}#1# in #2#{} chance to add", "{C:dark_edition}Oiled{}, {C:dark_edition}Cum Covered{}, or",
          "{C:dark_edition}Cursemarked{} edition", "to a random {C:attention}Joker" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ectoplasm, "text",
        { "Add {C:dark_edition}Lubricated{} to", "a random {C:attention}Joker,", "{C:red}-#1#{} hand size" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_hex, "text",
        { "Add {C:dark_edition}Cursemarked{} to a", "random {C:attention}Joker{}, destroy", "all other Harlots" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Lubricated" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Oiled" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Cum Covered" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Cursemarked" })
      SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_desc", { "Lubricated", "+#1# Joker Slot" })
    end
  end


  if config.Extras > 2 and config.WIP then
    SMODS.process_loc_text(G.localization.misc.labels, "foil", "Sweaty")
    SMODS.process_loc_text(G.localization.misc.labels, "holographic", "Steamy")
    SMODS.process_loc_text(G.localization.misc.labels, "polychrome", "Oiled")
    SMODS.process_loc_text(G.localization.misc.labels, "negative", "Lubricated")

    SMODS.process_loc_text(G.localization.descriptions.Edition.e_foil, "name", "Sweaty")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_holo, "name", "Steamy")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_polychrome, "name", "Oiled")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_negative, "name", "Lubricated")
    SMODS.process_loc_text(G.localization.descriptions.Edition.e_negative_consumable, "name", "Lubricated")

    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "name", "Sweaty Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "name", "Steamy Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "name", "Oiled Tag")
    SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "name", "Lubricated Tag")


    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_foil_desc", { "Sweaty", "+#1# Chips" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_holo_desc", { "Steamy", "+#1# Mult" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_polychrome_desc", { "Oiled", "X#1# Mult" })
    SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_consumable_desc",
      { "Lubricated", "+#1# consumable Slot" })
    SMODS.process_loc_text(G.localization.descriptions.Voucher.v_hone, "text",
      { "{C:dark_edition}Sweaty{}, {C:dark_edition}Steamy{}, and", "{C:dark_edition}Oiled{} cards",
        "appear {C:attention}#1#X{} more often" })
    SMODS.process_loc_text(G.localization.descriptions.Voucher.v_glow_up, "text",
      { "{C:dark_edition}Sweaty{}, {C:dark_edition}Steamy{}, and", "{C:dark_edition}Oiled{} cards",
        "appear {C:attention}#1#X{} more often" })
    SMODS.process_loc_text(G.localization.descriptions.Spectral.c_aura, "text",
      { "Add {C:dark_edition}Sweaty{}, {C:dark_edition}Steamy{},", "or {C:dark_edition}Oiled{} effect to",
        "{C:attention}1{} selected card in hand" })

    if config.Names then
      SMODS.process_loc_text(G.localization.descriptions.Tarot.c_wheel_of_fortune, "text",
        { "{C:green}#1# in #2#{} chance to add", "{C:dark_edition}Sweaty{}, {C:dark_edition}Steamy{}, or",
          "{C:dark_edition}Oiled{} edition", "to a random {C:attention}Harlot" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ectoplasm, "text",
        { "Add {C:dark_edition}Lubricated{} to", "a random {C:attention}Harlot,", "{C:red}-#1#{} hand size" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_hex, "text",
        { "Add {C:dark_edition}Oiled{} to a", "random {C:attention}Harlot{}, destroy", "all other Harlots" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Lubricated" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Sweaty" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Steamy" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "text",
        { "Next base edition shop", "Harlot is free and", "becomes {C:dark_edition}Oiled" })
      SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_desc", { "Lubricated", "+#1# Harlot Slot" })
    else
      SMODS.process_loc_text(G.localization.descriptions.Tarot.c_wheel_of_fortune, "text",
        { "{C:green}#1# in #2#{} chance to add", "{C:dark_edition}Sweaty{}, {C:dark_edition}Steamy{}, or",
          "{C:dark_edition}Oiled{} edition", "to a random {C:attention}Joker" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_ectoplasm, "text",
        { "Add {C:dark_edition}Lubricated{} to", "a random {C:attention}Joker,", "{C:red}-#1#{} hand size" })
      SMODS.process_loc_text(G.localization.descriptions.Spectral.c_hex, "text",
        { "Add {C:dark_edition}Oiled{} to a", "random {C:attention}Joker{}, destroy", "all other Harlots" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_negative, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Lubricated" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_foil, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Sweaty" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_holo, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Steamy" })
      SMODS.process_loc_text(G.localization.descriptions.Tag.tag_polychrome, "text",
        { "Next base edition shop", "Joker is free and", "becomes {C:dark_edition}Oiled" })
      SMODS.process_loc_text(G.localization.misc.v_dictionary, "ml_negative_desc", { "Lubricated", "+#1# Joker Slot" })
    end
  end


  if config.Hand_Naming > 1 then
    SMODS.process_loc_text(G.localization.misc.poker_hands, "High Card", "Tease")
    SMODS.process_loc_text(G.localization.misc.poker_hands, "Pair", "Couple")
    SMODS.process_loc_text(G.localization.misc.poker_hands, "Two Pair", "Double Date")
    SMODS.process_loc_text(G.localization.misc.poker_hands, "Three of a Kind", "Threesome")
    SMODS.process_loc_text(G.localization.misc.poker_hands, "Four of a Kind", "Foursome")
    SMODS.process_loc_text(G.localization.misc.poker_hands, "Five of a Kind", "Gangbang")

    if config.Hand_Naming > 2 then
      -- Don't have any good ideas for straights yet.
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Straight", "Harem")

      SMODS.process_loc_text(G.localization.misc.poker_hands, "Flush", "Heat")
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Full House", "Full Bordello")
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Royal Flush", "Royal Heat")
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Flush House", "Busy Bordello")
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Flush Five", "Grand Gangbang")
      SMODS.process_loc_text(G.localization.misc.poker_hands, "Straight Flush", "Heated Harem")

      SMODS.process_loc_text(G.localization.descriptions.Joker.j_four_fingers, "text",
        { "All {C:attention}Heats{} and", "{C:attention}Harems{} can be", "made with {C:attention}4{} cards" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_runner, "text",
        { "Gains {C:chips}+#2#{} Chips", "if played hand", "contains a {C:attention}Harem{}",
          "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_superposition, "text",
        { "Create a {C:tarot}Tarot{} card if", "poker hand contains an", "{C:attention}Ace{} and a {C:attention}Harem{}",
          "{C:inactive}(Must have room)" })
      SMODS.process_loc_text(G.localization.descriptions.Joker.j_shortcut, "text",
        { "Allows {C:attention}Harems{} to be", "made with gaps of {C:attention}1 rank",
          "{C:inactive}(ex: {C:attention}10 8 6 5 3{C:inactive})" })
    end
  end
end
