local config = SMODS.current_mod.config

if config.Alt_Versions then
  SMODS.Atlas {
    key = 'AltVersions',
    path = 'AltVersions.png',
    px = 71,
    py = 95
  }
end

-- Joker Textures
if config.Jokers then
  if config.Names then
    local silent = true
    SMODS.Atlas {
      key = "Joker",
      path = "BalustroJokers2.png",
      px = 71,
      py = 95,
      prefix_config = { key = false }
    }
    SMODS.Joker:take_ownership('j_wee', { pos = { x = 3, y = 6 }, prefix_config = { key = false } }, silent)
  else
    local silent = true
    SMODS.Atlas {
      key = "Joker",
      path = "BalustroJokers2.png",
      px = 71,
      py = 95,
      prefix_config = { key = false }
    }
    SMODS.Joker:take_ownership('j_wee', { pos = { x = 3, y = 6 }, prefix_config = { key = false } }, silent)
  end

  if config.WIP then
    SMODS.Atlas {
      key = "HalfSoul",
      path = "HalfJokerSoul.png",
      px = 71,
      py = 95
    }
    SMODS.Joker:take_ownership('j_half', {
      atlas = "HalfSoul",
      pos = { x = 0, y = 0 },
      soul_pos = { x = 1, y = 0 },
      prefix_config = { key = false }
    }, silent)
  end
end

-- Deck Textures
if config.Decks then
  SMODS.Atlas {
    key = "centers",
    path = "BalustroEnhancers.png",
    px = 71,
    py = 95,
    prefix_config = { key = false }
  }
end

-- Consumable/Booster Textures
if config.NSFW then
  SMODS.Atlas {
    key = "LustTarot",
    path = "BalustroConsumeables.png",
    px = 71,
    py = 95
  }
else
  SMODS.Atlas {
    key = "LustTarot",
    path = "BalustroConsumeablesSFW.png",
    px = 71,
    py = 95,
    raw_key = false
  }
end
SMODS.Atlas {
  key = "Booster",
  path = "BalustroBoosters.png",
  px = 71,
  py = 95,
  prefix_config = { key = false }
}

if config.Planets then
  local silent = true
  SMODS.Consumable:take_ownership('c_jupiter', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_saturn', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_uranus', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_planet_x', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
end
if config.Tarots then
  local silent = true
  SMODS.Consumable:take_ownership('c_judgement', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
end
if config.Spectrals then
  local silent = true
  SMODS.Consumable:take_ownership('c_familiar', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_grim', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_trance', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_ouija', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_ectoplasm', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  SMODS.Consumable:take_ownership('c_immolate', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  if config.Alt_Versions then
    SMODS.Consumable:take_ownership('c_ankh',
      { atlas = 'AltVersions', pos = { x = 0, y = 0 }, prefix_config = { key = false } },
      silent)
  else
    SMODS.Consumable:take_ownership('c_ankh', { atlas = 'LustTarot', prefix_config = { key = false } }, silent)
  end
end

-- if config.WIP then
--    SMODS.Consumable:take_ownership('c_incantation', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_talisman', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_aura', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_wraith', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_sigil', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_deja_vu', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_hex', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_medium', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_cryptid', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_soul', {atlas = 'LustTarot'})
--    SMODS.Consumable:take_ownership('c_black_hole', {atlas = 'LustTarot'})
-- end

-- Deck Skins
-- Balustro Cards
SMODS.Atlas {
  key = 'BalustroPlayingCards',
  path = 'CardSkins/BalustroPlayingCards.png',
  px = 71,
  py = 95
}
SMODS.DeckSkin {
  key = 'BalustroHearts',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Hearts',
  lc_atlas = 'BalustroPlayingCards',
  loc_txt = {
    ['en-us'] = 'Lost to Lust'
  },
}
SMODS.DeckSkin {
  key = 'BalustroClubs',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Clubs',
  lc_atlas = 'BalustroPlayingCards',
  loc_txt = {
    ['en-us'] = 'Gorging in Gluttony'
  },
}
SMODS.DeckSkin {
  key = 'BalustroDiamonds',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Diamonds',
  lc_atlas = 'BalustroPlayingCards',
  loc_txt = {
    ['en-us'] = 'Gambling for Greed'
  },
}
SMODS.DeckSkin {
  key = 'BalustroSpades',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Spades',
  lc_atlas = 'BalustroPlayingCards',
  loc_txt = {
    ['en-us'] = 'Wild with Wrath'
  },
}
-- Lady Luck Cards
SMODS.Atlas {
  key = 'LuckPlayingCardsLC',
  path = 'CardSkins/LadyLuckCardsLC.png',
  px = 71,
  py = 95
}
SMODS.Atlas {
  key = 'LuckPlayingCardsHC',
  path = 'CardSkins/LadyLuckCardsHC.png',
  px = 71,
  py = 95
}
SMODS.DeckSkin {
  key = 'LuckHearts',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Hearts',
  lc_atlas = 'LuckPlayingCardsLC',
  hc_atlas = 'LuckPlayingCardsHC',
  loc_txt = {
    ['en-us'] = "Lady Luck's Hearts"
  },
}
SMODS.DeckSkin {
  key = 'LuckClubs',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Clubs',
  lc_atlas = 'LuckPlayingCardsLC',
  hc_atlas = 'LuckPlayingCardsHC',
  loc_txt = {
    ['en-us'] = "Lady Luck's Clubs"
  },
}
SMODS.DeckSkin {
  key = 'LuckDiamonds',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Diamonds',
  lc_atlas = 'LuckPlayingCardsLC',
  hc_atlas = 'LuckPlayingCardsHC',
  loc_txt = {
    ['en-us'] = "Lady Luck's Diamonds"
  },
}
SMODS.DeckSkin {
  key = 'LuckSpades',
  ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' },
  suit = 'Spades',
  lc_atlas = 'LuckPlayingCardsLC',
  hc_atlas = 'LuckPlayingCardsHC',
  loc_txt = {
    ['en-us'] = "Lady Luck's Spades"
  },
}
-- Stickers.
if config.Stickers == 2 then
  SMODS.Atlas {
    key = "stickers",
    path = "BalustroStickers.png",
    px = 71,
    py = 110,
    prefix_config = { key = false }
  }
elseif config.Stickers == 3 then
  SMODS.Atlas {
    key = "stickers",
    path = "BalustroSitckers2.png",
    px = 71,
    py = 110,
    prefix_config = { key = false }
  }
elseif config.Stickers > 3 then
  SMODS.Atlas {
    key = "stickers",
    path = "AltBalustroStickers.png",
    px = 71,
    py = 110,
    prefix_config = { key = false }
  }
end

-- Male versions.
if config.Male then
  local silent = true
  SMODS.Atlas {
    key = "MaleCards",
    path = "MaleCards.png",
    px = 71,
    py = 95,
    raw_key = false
  }
  SMODS.Consumable:take_ownership('c_ectoplasm', { atlas = 'MaleCards', pos = { x = 0, y = 0 } }, silent)
  SMODS.Booster:take_ownership('p_spectral_mega_1', { atlas = 'MaleCards', pos = { x = 1, y = 0 } }, silent)
end


-- Changes the shop.
if config['Shop Sign'] then
  SMODS.Atlas {
    key = "shop_sign",
    atlas_table = 'ANIMATION_ATLAS',
    path = "Brothel_sign.png",
    frames = 19,
    px = 113,
    py = 57,
    prefix_config = { key = false }
  }
end

-- Texture scaling.
if config.Texture_Scaling then
  G.SETTINGS.GRAPHICS.texture_scaling = 2
end

-- Balustro Title Screen
SMODS.Atlas {
  prefix_config = { key = false },
  key = "balatro",
  path = "BalustroTitle.png",
  px = 397,
  py = 216
}

-- Mod Icon
if config.Hand_Naming > 2 then
  SMODS.Atlas {
    key = "modicon",
    path = "BalustroIcon2.png",
    px = 32,
    py = 32
  }
else
  SMODS.Atlas {
    key = "modicon",
    path = "BalustroIcon.png",
    px = 32,
    py = 32
  }
end
