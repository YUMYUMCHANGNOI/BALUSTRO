local Balustro = SMODS.current_mod
local config = Balustro.config
G.FUNCS.Lust_save_and_apply = function(e)
  G.ACTIVE_MOD_UI = nil
  SMODS.save_all_config()
  SMODS.restart_game()
  SMODS.IN_MODS_TAB = nil
end

G.FUNCS.Lust_cycle_save = function(args)
  local ref = args.cycle_config.ref_value
  config[ref] = args.cycle_config.current_option
end

SMODS.current_mod.config_tab = function()
  local TexturesIn, TexturesOut = HEX('FE5F55'), HEX('f83b2f')
  local TextIn, TextOut = HEX('009dff'), HEX('008ee6')
  local MiscIn, MiscOut = HEX('f3b958'), HEX('e29000')
  local SaveApplyButton = HEX('c20606')
  return {
    n = G.UIT.ROOT,
    config = { r = 0.25, align = 'tm', padding = 0.5, colour = G.C.BLACK, minw = 15, minh = 8 },
    nodes = {
      {
        n = G.UIT.C,
        config = { r = 0.4, align = 'tl', padding = 0.25, colour = TexturesIn, minw = 4.5, minh = 7 },
        nodes = {
          {
            n = G.UIT.R,
            config = { tooltip = { text = { 'Visual options.' } }, r = 0.1, align = 'tm', padding = 0.2, colour = TexturesOut, outline = 0.7, outline_colour = G.C.WHITE, emboss = 0.1, minw = 4, minh = 1.1 },
            nodes = {
              { n = G.UIT.T, config = { text = 'Textures', align = 'cm', scale = 0.8, colour = G.C.UI.TEXT_LIGHT } } }
          },
          {
            n = G.UIT.R,
            config = { r = 0, align = 'tm', minw = 3, minh = 0 },
            nodes = {
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = TexturesOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Jokers' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'Clussy!' } }, shadow = true, text = 'Jokers', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = TexturesOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'NSFW' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { "Probably shouldn't play this", 'while at the office.' } }, shadow = true, text = 'NSFW', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              { n = G.UIT.R, config = { minh = 0.5, align = 'bm' } },
              {
                n = G.UIT.R,
                config = { r = 0.1, align = 'cm', padding = 0.1, colour = TexturesOut, outline = 0.7, outline_colour = G.C.WHITE, emboss = 0.1, maxw = 3.1, maxh = 1.1, can_collide = true, button = 'Balustro_misc_options', hover = true },
                nodes = {
                  { n = G.UIT.T, config = { text = 'Other Textures', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                }
              },
              { n = G.UIT.R, config = { minh = 1, align = 'bm' } },
              {
                n = G.UIT.R,
                config = { tooltip = { text = { 'Will restart Balatro to save', 'and apply all changes made.' } }, hover = true, minh = 0, align = 'bm', emboss = 0.15, colour = SaveApplyButton, button = "Lust_save_and_apply", outline = 0.3, outline_colour = G.C.WHITE, r = 0.5, shadow = true },
                nodes = {
                  {
                    n = G.UIT.R,
                    config = { padding = 0.2, r = 0, align = 'bm', minw = 0, minh = 0.5 },
                    nodes = {
                      { n = G.UIT.O, config = { object = DynaText({ string = { 'Save & Apply' }, colours = { G.C.UI.TEXT_LIGHT }, shadow = true, rotate = false, bump = true, scale = 0.5, silent = true }) } } }
                  },
                }
              } }
          },
          { n = G.UIT.R, config = { r = 0, align = 'bm', minw = 0, minh = 0.1 } },

        }
      },
      {
        n = G.UIT.C,
        config = { r = 0.4, align = 'tm', padding = 0.25, colour = TextIn, minw = 4.5, minh = 7 },
        nodes = {
          {
            n = G.UIT.R,
            config = { tooltip = { text = { 'Changes text for', 'a lewder atmosphere.' } }, r = 0.1, align = 'tm', padding = 0.2, colour = TextOut, outline = 0.7, outline_colour = G.C.WHITE, emboss = 0.1, minw = 4, minh = 1.1 },
            nodes = {
              { n = G.UIT.T, config = { text = 'Text', align = 'cm', scale = 0.8, colour = G.C.UI.TEXT_LIGHT } } }
          },
          {
            n = G.UIT.R,
            config = { r = 0, align = 'tm', minw = 3, minh = 0 },
            nodes = {
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = TextOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Names' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'All Jokers become Harlots, along', 'with specific name changes.' } }, shadow = true, padding = 0.2, text = 'Names', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = TextOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Descriptions' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'Changes a few descriptions. Mostly a WIP.' } }, shadow = true, padding = 0.2, text = 'Descriptions', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              }
            }
          },
          { n = G.UIT.R, config = { r = 0, align = 'tm', minw = 0, minh = 0.05 } },
          {
            n = G.UIT.R,
            config = { r = 0, align = 'tm', minw = 2, minh = 0, maxh = 0.3, padding = -0.2 },
            nodes = {
              { n = G.UIT.T, config = { shadow = true, text = 'Extras', align = 'tm', scale = 0.6, tooltip = { text = { 'Full includes changing the rarity', 'names, debuff names, and edition names.' } }, colour = G.C.UI.TEXT_LIGHT } } }
          },
          create_option_cycle { colour = TextOut, scale = 0.7, w = 2, shadow = true, options = { 'Off', 'Rarities', 'Full' }, current_option = config.Extras, ref_table = config, ref_value = 'Extras', opt_callback = 'Lust_cycle_save' },

          --
          {
            n = G.UIT.R,
            config = { r = 0, align = 'tm', minw = 3, minh = 0, maxh = 0.5, padding = -0.2 },
            nodes = {
              { n = G.UIT.T, config = { tooltip = { text = { 'Full has some names that might not be', 'clear enough on first glance. Also, probably', "turn this off if you're unfamiliar with hand types." } }, shadow = true, text = 'Hand Names', align = 'tm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
          },
          create_option_cycle { colour = TextOut, scale = 0.7, w = 2, shadow = true, options = { 'Off', 'Simple', 'Full' }, current_option = config.Hand_Naming, ref_table = config, ref_value = 'Hand_Naming', opt_callback = 'Lust_cycle_save' },
        }
      },
      {
        n = G.UIT.C,
        config = { r = 0.4, align = 'tr', padding = 0.25, colour = MiscIn, minw = 4.5, minh = 7 },
        nodes = {
          {
            n = G.UIT.R,
            config = { tooltip = { text = { 'Experimental or', 'optional features.' } }, r = 0.1, align = 'tm', padding = 0.2, colour = MiscOut, outline = 0.7, outline_colour = G.C.WHITE, emboss = 0.1, minw = 4, minh = 1.1 },
            nodes = {
              { n = G.UIT.T, config = { text = 'Misc', align = 'cm', scale = 0.8, colour = G.C.UI.TEXT_LIGHT } } }
          },
          { n = G.UIT.R, config = { r = 0, align = 'tm', minw = 0, minh = 0.02 } },
          {
            n = G.UIT.R,
            config = { r = 0, align = 'tm', minw = 2, minh = 0, maxh = 0.3, padding = -0.2 },
            nodes = {
              { n = G.UIT.T, config = { shadow = true, text = 'Stickers', align = 'tm', scale = 0.6, tooltip = { text = { 'Golden adds a special addition', 'to only golden stickers, while', 'Intrusive includes stickers that', 'can get in the way of card art.' } }, colour = G.C.UI.TEXT_LIGHT } } }
          },
          create_option_cycle { colour = MiscOut, scale = 0.7, w = 2.3, shadow = true, options = { 'Off', 'Lips', 'Golden', 'Intrustive' }, current_option = config.Stickers, ref_table = config, ref_value = 'Stickers', opt_callback = 'Lust_cycle_save' },
          {
            n = G.UIT.R,
            config = { padding = -0.15, r = 0, align = 'tm', minw = 3, minh = 0 },
            nodes = {
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = MiscOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Alt_Versions' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'Only makes Ankh pregnant at the moment.' } }, shadow = true, text = 'Alt Versions', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = MiscOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Male' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'Gives some textures a dick. Simple.' } }, shadow = true, text = 'Male Versions', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = MiscOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'WIP' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { text = { 'Self explanatory. A lot is still WIP. But, you', 'might want to toggle this off in the future?' } }, shadow = true, text = 'WIP', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
                  }
                }
              },
              { n = G.UIT.R, config = { r = 0, align = 'tm', minw = 0, minh = 0.5 } },
              {
                n = G.UIT.R,
                config = { r = 0, align = 'tl', minw = 0, minh = 0.8 },
                nodes = {
                  {
                    n = G.UIT.C,
                    config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
                    nodes = {
                      create_toggle { label = '', active_colour = MiscOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = 'Texture_Scaling' } }
                  },
                  {
                    n = G.UIT.C,
                    config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
                    nodes = {
                      { n = G.UIT.T, config = { tooltip = { title = '===DEBUG===', text = { 'Turns off forced pixel smoothing.', 'Only turn off if you run into', 'texture or performance issues.', '===DEBUG===' } }, text = 'Smoothing', align = 'cm', scale = 0.5, colour = TexturesOut } } }
                  }
                }
              },
            }
          }
        }
      }
    }
  }
end


SMODS.Atlas {
  key = 'BalustroIcons',
  path = 'BalustroIcons.png',
  px = 72,
  py = 72,
  prefix_config = { key = false }
}

G.FUNCS.go_to_DorianSS = function(e)
  love.system.openURL("https://subscribestar.adult/dorian-bates")
end
G.FUNCS.go_to_DorianTwit = function(e)
  love.system.openURL("https://twitter.com/DoriBation")
end
G.FUNCS.go_to_DorianBSky = function(e)
  love.system.openURL("https://bsky.app/profile/dorianbates.bsky.social")
end
G.FUNCS.go_to_TiltedTwit = function(e)
  love.system.openURL("https://twitter.com/mr_oddman")
end
G.FUNCS.go_to_TiltedBSky = function(e)
  love.system.openURL("https://bsky.app/profile/mr-oddman.bsky.social")
end
G.FUNCS.go_to_PMQSS = function(e)
  love.system.openURL("https://subscribestar.adult/papermoonqueen")
end
G.FUNCS.go_to_PMQTwit = function(e)
  love.system.openURL("https://twitter.com/PaperMoonQueen")
end
G.FUNCS.go_to_PMQBSky = function(e)
  love.system.openURL("https://bsky.app/profile/papermoonqueen.bsky.social")
end
G.FUNCS.go_to_NexusModsPage = function(e)
  love.system.openURL("https://www.nexusmods.com/balatro/mods/41")
end

SMODS.current_mod.credits_tab = function()
  local SubscribeStar1 = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 0, y = 0 })
  SubscribeStar1.states.drag.can = false
  local SubscribeStar2 = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 0, y = 0 })
  SubscribeStar2.states.drag.can = false
  local TiltTwit = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 1, y = 0 })
  TiltTwit.states.drag.can = false
  local PMQTwit = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 1, y = 0 })
  PMQTwit.states.drag.can = false
  local DoriTwit = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 1, y = 0 })
  DoriTwit.states.drag.can = false
  local TiltBSky = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 3, y = 0 })
  TiltBSky.states.drag.can = false
  local PMQBSky = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 3, y = 0 })
  PMQBSky.states.drag.can = false
  local DoriBSky = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 3, y = 0 })
  DoriBSky.states.drag.can = false
  local NexusM = Sprite(0, 0, 1.2, 1.2, G.ASSET_ATLAS["BalustroIcons"], { x = 2, y = 0 })
  NexusM.states.drag.can = false


  local RH = 1.6                              -- Row Height
  local RW = 17.3                             -- Row Width
  local PW = 14.5                             -- Panel Width
  local SW = 3                                -- Spacer Width
  local PI, PO = G.C.SO_2.Spades, G.C.PURPLE  -- Purple In, Purple Out
  local BI, BO = G.C.SO_2.Clubs, G.C.BLUE     -- Blue In, Blue Out
  local RI, RO = G.C.SO_2.Hearts, G.C.RED     -- Red In, Red Out
  local YI, YO = G.C.SO_2.Diamonds, G.C.MONEY -- Yellow In, Yellow Out
  local WHITE = G.C.WHITE

  -- UI Root Box
  return {
    n = G.UIT.ROOT,
    config = { r = 0.25, align = 'tm', padding = 0.1, colour = G.C.BLACK, minw = 18, minh = 8 },
    nodes = {
      -- Column
      {
        n = G.UIT.C,
        config = { r = 0.4, align = 'tm', minw = 16, minh = 7, padding = 0.1 },
        nodes = {
          -- Row 1
          {
            n = G.UIT.R,
            config = { r = 0.1, align = 'tl', padding = 0.1, minw = RW, minh = RH },
            nodes = {
              -- Ribbon 1
              {
                n = G.UIT.R,
                config = { r = 0.1, align = 'tl', padding = 0.2, minw = PW, minh = RH, colour = RO, emboss = 0.05 },
                nodes = {

                  -- Plate
                  {
                    n = G.UIT.C,
                    config = { align = 'cl', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { r = 0.1, align = 'cm', padding = 0.2, colour = RI, outline = 0.7, outline_colour = WHITE, emboss = 0.1, minw = 4, minh = 1.1, can_collide = true },
                        nodes = {
                          -- Name
                          { n = G.UIT.T, config = { text = 'Someone23832', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      }, -- End of Plate
                    }
                  },     -- End of Plate Column

                  -- Information
                  {
                    n = G.UIT.C,
                    config = { align = 'cm', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { align = 'tl', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Main', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                      {
                        n = G.UIT.R,
                        config = { align = 'bl', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Programmer', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                    }
                  }, -- End of Info Column
                  --Buttons on the Right
                  {
                    n = G.UIT.C,
                    config = { align = 'cr', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      -- Row on the Left
                      {
                        n = G.UIT.R,
                        config = { align = 'cr', minw = 8.1, minh = 0, padding = 0 },
                        nodes = {
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = RI, button = 'Balustro_misc_options' --[['go_to_NexusModsPage']], shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = NexusM } },
                            }
                          }, -- End of Button 1
                        }
                      },     -- End of Left Row
                    }
                  },         -- End of Buttons
                }
              },             -- End of Ribbon 1
            }
          },                 -- End of Row 1

          -- Row 2
          {
            n = G.UIT.R,
            config = { r = 0.1, align = 'tr', padding = 0.1, minw = RW, minh = RH },
            nodes = {
              -- Ribbon 2
              {
                n = G.UIT.R,
                config = { r = 0.1, align = 'tr', padding = 0.2, minw = PW, minh = RH, colour = BO, emboss = 0.05 },
                nodes = {
                  -- Buttons on Left
                  {
                    n = G.UIT.C,
                    config = { align = 'cl', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      -- Row on the Left
                      {
                        n = G.UIT.R,
                        config = { align = 'cl', minw = 8.55, minh = 0, padding = 0.1 },
                        nodes = {
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = BI, button = 'go_to_DorianSS', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = SubscribeStar1 } },
                            }
                          }, -- End of Button 1
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = BI, button = 'go_to_DorianTwit', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = DoriTwit } },
                            }
                          }, -- End of Button 2
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = BI, button = 'go_to_DorianBSky', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = DoriBSky } },
                            }
                          }, -- End of Button 3
                        }
                      },     -- End of Left Row
                    }
                  },         -- End of Buttons

                  -- Information
                  {
                    n = G.UIT.C,
                    config = { align = 'cm', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { align = 'tr', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Joker', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                      {
                        n = G.UIT.R,
                        config = { align = 'br', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Artist', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                    }
                  }, -- End of Info Column

                  -- Plate
                  {
                    n = G.UIT.C,
                    config = { align = 'cr', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { r = 0.1, align = 'cm', padding = 0.2, colour = BI, outline = 0.7, outline_colour = WHITE, emboss = 0.1, minw = 4, minh = 1.1, can_collide = true },
                        nodes = {
                          -- Name
                          { n = G.UIT.T, config = { text = 'Dorian Bates', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      }, -- End of Plate
                    }
                  },     -- End of Plate Column
                }
              },         -- End of Ribbon 2
            }
          },             -- End of Row 2
          -- Row 3
          {
            n = G.UIT.R,
            config = { r = 0.1, align = 'tl', padding = 0.1, minw = RW, minh = RH },
            nodes = {
              -- Ribbon 3
              {
                n = G.UIT.R,
                config = { r = 0.1, align = 'tl', padding = 0.2, minw = PW, minh = RH, colour = YO, emboss = 0.05 },
                nodes = {
                  -- Plate
                  {
                    n = G.UIT.C,
                    config = { align = 'cl', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { r = 0.1, align = 'cm', padding = 0.2, colour = YI, outline = 0.7, outline_colour = WHITE, emboss = 0.1, minw = 4, minh = 1.1, can_collide = true },
                        nodes = {
                          -- Name
                          { n = G.UIT.T, config = { text = 'Mr. Oddman', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      }, -- End of Plate
                    }
                  },     -- End of Plate Column
                  -- Information
                  {
                    n = G.UIT.C,
                    config = { align = 'cm', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { align = 'tl', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Consumable', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                      {
                        n = G.UIT.R,
                        config = { align = 'bl', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Artist', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                    }
                  }, -- End of Info Column
                  --Buttons on the Right
                  {
                    n = G.UIT.C,
                    config = { align = 'cr', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      -- Row on the Left
                      {
                        n = G.UIT.R,
                        config = { align = 'cr', minw = 8.2, minh = 0, padding = 0.1 },
                        nodes = {
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = YI, button = 'go_to_TiltedTwit', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = TiltTwit } },
                            }
                          }, -- End of Button 1
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = YI, button = 'go_to_TiltedBSky', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = TiltBSky } },
                            }
                          }, -- End of Button 2
                        }
                      },     -- End of Left Row
                    }
                  },         -- End of Buttons
                }
              },             -- End of Ribbon 3
            }
          },                 -- End of Row 3

          -- Row 4
          {
            n = G.UIT.R,
            config = { r = 0.1, align = 'tr', padding = 0.1, minw = RW, minh = RH },
            nodes = {
              -- Ribbon 4
              {
                n = G.UIT.R,
                config = { r = 0.1, align = 'tr', padding = 0.2, minw = PW, minh = RH, colour = PO, emboss = 0.05 },
                nodes = {
                  -- Buttons on the Left
                  {
                    n = G.UIT.C,
                    config = { align = 'cl', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      -- Row on the Left
                      {
                        n = G.UIT.R,
                        config = { align = 'cl', minw = 8, minh = 0, padding = 0.1 },
                        nodes = {
                          --Button
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = PI, button = 'go_to_PMQSS', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = SubscribeStar2 } },
                            }
                          }, -- End of Button 1
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = PI, button = 'go_to_PMQTwit', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = PMQTwit } },
                            }
                          }, -- End of Button 2
                          {
                            n = G.UIT.C,
                            config = { align = "cm", minw = 0.8, minh = 0.8, padding = 0.05, r = 0.1, hover = true, colour = PI, button = 'go_to_PMQBSky', shadow = true, outline = 0.5, outline_colour = WHITE },
                            nodes = {
                              { n = G.UIT.O, config = { object = PMQBSky } },
                            }
                          }, -- End of Button 3
                        }
                      },     -- End of Left Row
                    }
                  },         -- End of Buttons

                  -- Information
                  {
                    n = G.UIT.C,
                    config = { align = 'cm', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { align = 'tr', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Voucher', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                      {
                        n = G.UIT.R,
                        config = { align = 'br', minw = 0, minh = 0, padding = 0 },
                        nodes = {
                          { n = G.UIT.T, config = { text = 'Artist', align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      },
                    }
                  }, -- End of Info Column

                  -- Plate
                  {
                    n = G.UIT.C,
                    config = { align = 'cr', minw = 0, minh = 0, padding = 0 },
                    nodes = {
                      {
                        n = G.UIT.R,
                        config = { r = 0.1, align = 'cm', padding = 0.2, colour = PI, outline = 0.7, outline_colour = WHITE, emboss = 0.1, minw = 4, minh = 1.1, can_collide = true },
                        nodes = {
                          -- Name
                          { n = G.UIT.T, config = { text = 'PaperMoonQueen', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
                        }
                      }, -- End of Plate
                    }
                  },     -- End of Plate Column
                }
              },         -- End of Ribbon 2
            }
          }              -- End of Row 2
        }
      }                  -- End of Column
    }
  }                      -- End of Root
end


G.FUNCS.Balustro_misc_options = function(args)
  G.FUNCS.overlay_menu({
    definition = create_UIBox_Balustro_misc_settings()
  })
end

-- Come back and switch to pairs/ipairs
-- Add in tooltips/Text Colors/Box Colors
function create_Balustro_misc_options()
  local TexturesIn, TexturesOut = HEX('FE5F55'), HEX('f83b2f')
  local lists = { {
    'Tarots',
    'Planets',
    'Spectrals'
  },
    {
      'Decks',
      'Vouchers',
      'Shop Sign'
    } }
  local output = {
    n = G.UIT.R,
    config = { align = 'cm', minh = 5 },
    nodes = {
      {
        n = G.UIT.C,
        config = { align = 'cm' },
        nodes = {
          {
            n = G.UIT.R,
            config = { r = 0.1, align = 'cm', padding = -0.3, colour = TexturesOut, outline = 0.7, outline_colour = G.C.WHITE, emboss = 0.1, minw = 1.3, minh = 3.9, can_collide = true },
            nodes = {
              -- Name
              { n = G.UIT.T, config = { vert = true, text = 'Other Textures', align = 'cm', scale = 0.6, colour = G.C.UI.TEXT_LIGHT, shadow = true } },
            }
          },
        }
      },
      { n = G.UIT.C, config = { minw = 1 } }
    }
  }
  for i = 1, #lists do
    local col = { n = G.UIT.C, config = { padding = 0.1, align = 'cl' }, nodes = {} }
    for j = 1, #lists[i] do
      local option = lists[i][j]
      local row = {
        n = G.UIT.R,
        config = { padding = 0.1, colour = G.C.UI.TRANSPARENT_DARK, r = 1 },
        nodes = {
          {
            n = G.UIT.C,
            config = { r = 0, align = 'cl', minw = 0.8, minh = 0 },
            nodes = {
              create_toggle { label = '', active_colour = TexturesOut, scale = 1, w = 0, shadow = true, ref_table = config, ref_value = option } }
          },
          {
            n = G.UIT.C,
            config = { padding = 0.2, r = 0, align = 'cl', minw = 2, minh = 0 },
            nodes = {
              { n = G.UIT.T, config = { shadow = true, text = option, align = 'cm', scale = 0.5, colour = G.C.UI.TEXT_LIGHT } } }
          }
        }
      }
      table.insert(col.nodes, row)
    end
    table.insert(output.nodes, col)
  end
  return output
end

function create_UIBox_Balustro_misc_settings()
  local TexturesIn, TexturesOut = HEX('FE5F55'), HEX('f83b2f')
  local tab = create_UIBox_generic_options({
    back_func = 'Balustro_misc_options_exit',
    contents = {
      {
        n = G.UIT.R,
        config = { colour = TexturesIn, r = 0.3, align = 'cm', minw = 11, outline = 5, outline_colour = G.C.BLACK },
        nodes = { create_Balustro_misc_options() }
      }
    },
  })
  return tab
end

function G.FUNCS.Balustro_misc_options_exit()
  G.SETTINGS.paused = true
  SMODS.save_mod_config(Balustro)
  SMODS.LAST_SELECTED_MOD_TAB = "config"
  G.FUNCS.overlay_menu({
    definition = create_UIBox_mods(Balustro)
  })
end
