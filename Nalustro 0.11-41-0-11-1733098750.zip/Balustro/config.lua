return {
  ["Jokers"] = true,
  ["Tarots"] = true,
  ["Planets"] = true,
  ["Spectrals"] = true,
  ["Decks"] = true,
  ["Vouchers"] = true,
  ["Shop Sign"] = true,
  ["NSFW"] = true,
  
  ["Names"] = true,
  ["Descriptions"] = false,
  ["Extras"] = 3,
  ["Hand_Naming"] = 3,
  
  ["Stickers"] = 3,
  ["Alt_Versions"] = false,
  ["Male"] = false,
  ["WIP"] = true,
  ["Texture_Scaling"] = true
  }